import { Game } from "../Game";

// ゲーム難易度上級
export const Hard = () => {
  return (
    <div className="Hard">
      <Game mode={"hard"} />
    </div>
  );
};
