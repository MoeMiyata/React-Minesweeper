import { Game } from "../Game";

// ゲーム難易度中級
export const Normal = () => {
  return (
    <div className="Normal">
      <Game mode={"normal"} />
    </div>
  );
};
