import { Game } from "../Game";

// ゲーム難易度初級
export const Easy = () => {
  return (
    <div className="Easy">
      <Game mode={"easy"} />
    </div>
  );
};
